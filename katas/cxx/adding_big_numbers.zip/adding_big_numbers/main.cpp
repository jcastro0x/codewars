// Kata: Adding Big Numbers

#include <charconv>
#include <gtest/gtest.h>
#include <string>
#include <vector>

template<typename T = int>
class BigNumber
{
    using Type = std::vector<T>;

public:
    explicit BigNumber(const std::string& string)
        : number_(extract_values(string))
    {
    }

    BigNumber operator+(const BigNumber& other) const
    {
        BigNumber copy(*this);

        // Find the array with more values
        const Type& higher_values = number_.size() > other.number_.size() ? number_ : other.number_;
        const Type& lower_values = number_.size() > other.number_.size() ? other.number_ : number_;

        // The worst possible case is when we duplicate of number of digits after a sum
        Type result(number_.size() * 2);

        for (int i = 0; i < higher_values.size(); ++i)
        {
            int sum = higher_values[i];
            if (i < lower_values.size())
            {
                sum += lower_values[i];
            }

            char chars[2];
            std::to_chars(chars, chars + 2, sum);

            result[i] = chars[0];
        }

        return copy;
    }

    [[nodiscard]] std::string stringify() const
    {
        std::string result(number_.size(), '\0');
        for (int i = 0; i < number_.size(); ++i)
        {
            constexpr int zero_ascii = '0';
            result[i] = zero_ascii + number_[i];
        }

        return result;
    }

private:
    Type extract_values(const std::string& string)
    {
        Type values(string.length());

        for (int i = 0; i < string.length(); ++i)
        {
            constexpr int zero_ascii = '0';
            values[i] = string[i] - zero_ascii;
        }

        return values;
    }

    Type number_;
};



std::string add(const std::string& a, const std::string& b)
{
    const BigNumber number_a(a);
    const BigNumber number_b(b);

    const BigNumber result = number_a + number_b;
    std::cout << number_a.stringify() << " + " << number_b.stringify() << " = " << result.stringify() << std::endl;

    return result.stringify();
}

TEST(Codewars, adding_big_numbers)
{
    EXPECT_STREQ(add("123", "456").c_str(), "579");
    EXPECT_STREQ(add("0", "0").c_str(), "0");
    EXPECT_STREQ(add("99", "2").c_str(), "101");
    EXPECT_STREQ(add("10", "35679").c_str(), "35689");
    EXPECT_STREQ(add("", "5").c_str(), "5");
    EXPECT_STREQ(add("192", "").c_str(), "192");
    EXPECT_STREQ(add("9999", "1111").c_str(), "11110");
}
